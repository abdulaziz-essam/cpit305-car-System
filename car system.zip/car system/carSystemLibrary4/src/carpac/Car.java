package carpac;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;

public class Car {

    String carName;
    int carID;
    String brand;
    String model;
    double price;
    boolean av;
static ArrayList<Car> cars = null;
public static ArrayList<Car> storeCars(Connection con) throws SQLException {
        cars = new ArrayList<Car>();
        Statement stat = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
        ResultSet rs = null;

        boolean x = stat.execute("select * from car");
        while (true) {

            rs = stat.getResultSet();
            try {
                if (!rs.next()) {
                    break;
                }

//String carN, int carID, String brand, String model, double price, boolean avilable
          
String carName = rs.getString(1);
                int carID = rs.getInt(2);
                String brand = rs.getString(3);
                String model = rs.getString(4);
                double price = rs.getDouble(5);
                boolean avi = rs.getBoolean(6);
              
        
                  
                  
               
                System.out.println(avi);
                Car car = new Car(carName, carID, brand, model, price, avi);
                cars.add(car);

            } catch (SQLException e) {
                System.out.println(e.getMessage());
            }

        }

        return cars;

    }

    @Override
    public String toString() {
        return "Car{" + "carName=" + carName + ", carID=" + carID + ", brand=" + brand + ", model=" + model + ", price=" + price + ", av=" + av + '}';
    }
    public String getComName() {
        return carName;
    }

    public void setComName(String comName) {
        this.carName = comName;
    }

    public int getCarID() {
        return carID;
    }

    public void setCarID(int carID) {
        this.carID = carID;
    }

    public String getBrand() {
        return brand;
    }

    public void setBrand(String brand) {
        this.brand = brand;
    }

    public String getModel() {
        return model;
    }

    public void setModel(String model) {
        this.model = model;
    }

    public double getPrice() {
        return price;
    }

    public void setPrice(double price) {
        this.price = price;
    }

    public boolean getAv() {
        return av;
    }

    public void setAv(boolean av) {
        this.av = av;
    }

    public Car(String comName, int carID, String brand, String model, double price, boolean avilable) {
        this.carName = comName;
        this.carID = carID;
        this.brand = brand;
        this.model = model;
        this.price = price;
        this.av = avilable;
    }
    
//   car_name	car_id	brand	model	price_per_day	avilable
 public static void insert_car( Connection con ,String carN, int carID, String brand, String model, double price, boolean avilable ) throws SQLException{
    
       try {
        PreparedStatement pstat=con.prepareStatement("insert into car values (?,?,?,?,?,?)");
           
        pstat.setString(1, carN);
            pstat.setInt(2, carID);
            pstat.setString(3, brand);
            pstat.setString(4, model);
               pstat.setDouble(5 , price);
               pstat.setBoolean(6, true);
            pstat.execute();   
           
       } catch (Exception e) {
           System.out.println( e.getMessage());
       }

   } 

 
}
