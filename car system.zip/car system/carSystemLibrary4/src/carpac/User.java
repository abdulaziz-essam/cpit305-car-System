package carpac;

import java.io.Serializable;
import java.sql.Array;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.*;
import java.util.ArrayList;


public class User  implements Serializable{
   String name;
   String password;
   int id;
   String email;
   int phoneNumber;
  static ArrayList<User> users;

    public User(String name, String password, int id, String email, int phoneNumber) {
        this.name = name;
        this.password = password;
        this.id = id;
        this.email = email;
        this.phoneNumber = phoneNumber;
    }
public static ArrayList<User>storeUSers(Connection con) throws SQLException{
      users=new ArrayList<User>() ;
    Statement stat=con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
         ResultSet rs = null ;
         
         boolean x = stat.execute("select * from user");
      while (true) {
     
        rs=stat.getResultSet();
         try {
                if (!rs.next()) {
                    break;
                }
//String name, String password, int id, String email, int phoneNumbe
                 String name=  rs.getString(1);
                        String password= rs.getString(2);
                        int id=rs.getInt(3);
                          String email=rs.getString(4) ;
                       int phone= rs.getInt(5);
         User  temp=  new User(name, password, id, email, phone);
         users.add(temp);
                 
            } catch (SQLException e) {System.out.println( e.getMessage()); }
                      
    } 
    
    
    return users;
    
}
    public ArrayList<User> getUsers() {
        
        return users;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public int getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(int phoneNumber) {
        this.phoneNumber = phoneNumber;
    }
//   public 
//   public static void insert_user( Connection con ,String name, String password, int id, String email, int phoneNumbe ) throws SQLException{
//    
//       try {
//           
//        PreparedStatement pstat=con.prepareStatement("insert into user values (?,?,?,?,?)");
//pstat.setString(1, name);
//            pstat.setString(2, password);
//            pstat.setInt(3, id);
//            pstat.setString(4, email);
//               pstat.setInt(5 , phoneNumbe);
//            pstat.execute();   
//       } catch (Exception e) {
//           System.out.println( e.getMessage());
//       }
//
//   } 

    @Override
    public String toString() {
        return "User{" + "name=" + name + ", password=" + password + ", id=" + id + ", email=" + email + ", phoneNumber=" + phoneNumber + '}';
    }
}
