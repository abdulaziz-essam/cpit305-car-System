package carpac;

import static carpac.User.users;
import static com.sun.org.apache.xalan.internal.lib.ExsltDatetime.date;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.Date;

public class Res {
//  int day[]=new int[30];
//      Date Date_Start_rent, Date_Finish_Rent;

    int resid;
    String start, end;
    int userID;
    int carID;
    double totalPrice;

    public Res(int resid, String start, String end, int userID, int carID) {
        this.resid = resid;
        this.start = start;
        this.end = end;
        this.userID = userID;
        this.carID = carID;
      
    }

    public int getResid() {
        return resid;
    }

    public void setResid(int resid) {
        this.resid = resid;
    }

    public String getStart() {
        return start;
    }

    public String getEnd() {
        return end;
    }

    public int getUserID() {
        return userID;
    }

    public int getCarID() {
        return carID;
    }

    public double getTotalPrice() {
        return totalPrice;
    }

    public void setStart(String start) {
        this.start = start;
    }

    public void setEnd(String end) {
        this.end = end;
    }

    public void setUserID(int userID) {
        this.userID = userID;
    }

    public void setCarID(int carID) {
        this.carID = carID;
    }

    public void setTotalPrice(double totalPrice) {
        this.totalPrice = totalPrice;
    }
      public static void insert_res( Connection con ,int resID, String startDate, String endDate, int userId, int carID ) throws SQLException{
    
       try {
         
        PreparedStatement pstat=con.prepareStatement("insert into reservation values (?,?,?,?,?)");
pstat.setInt(1, resID);
            pstat.setString(2, startDate);
            pstat.setString(3, endDate);
            pstat.setInt(4, userId);
               pstat.setInt(5 , carID);
            pstat.execute();   
       } 
       catch (Exception e) {
           
           System.out.println( e.getMessage());
       
       }

   } 
//    public  void update_res(Connection con) throws SQLException{
//     
//    Statement stat=con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
//         ResultSet rs = null ;
//
//         boolean x = stat.execute("select * from user");
//      while (true) {
//     
//        rs=stat.getResultSet();
//         try {
//                if (!rs.next()) {
//                    break;
//                }
////String name, String password, int id, String email, int phoneNumbe
//                 String name=  rs.getString(1);
//                        String password= rs.getString(2);
//                        int id=rs.getInt(3);
//                          String email=rs.getString(4) ;
//                       int phone= rs.getInt(5);
//         User  temp=  new User(name, password, id, email, phone);
//         users.add(temp);
//                 
//            } catch (SQLException e) {System.out.println( e.getMessage()); }
//                      
//    } 
//    
//    
//    
//}
//    //         res_id	sdate	edate	user_id	car_id	tottal_price
//     public static void new_res( Connection con ,String carN, int carID, String brand, String model, double price, boolean avilable ) throws SQLException{
//    
//       try {
//        PreparedStatement pstat=con.prepareStatement("insert into car values (?,?,?,?,?,?)");
//           
//        pstat.setString(1, re);
//            pstat.setInt(2, carID);
//            pstat.setString(3, brand);
//            pstat.setString(4, model);
//               pstat.setDouble(5 , price);
//               pstat.setBoolean(6, avilable);
//            pstat.execute();   
//           
//       } catch (Exception e) {
//           System.out.println( e.getMessage());
//       }
//
//   } 
public static ArrayList<Res> storeCars(Connection con) throws SQLException {
        ArrayList<Res> res = new ArrayList<Res>();
        Statement stat = con.createStatement(ResultSet.TYPE_SCROLL_SENSITIVE, ResultSet.CONCUR_UPDATABLE);
        ResultSet rs = null;

        boolean x = stat.execute("select * from reservation");
        while (true) {

            rs = stat.getResultSet();
            try {
                if (!rs.next()) {
                    break;
                }

//String carN, int carID, String brand, String model, double price, boolean avilable
          

                int resID = rs.getInt(1);
                String start = rs.getString(2);
                String end = rs.getString(3);
                int userId = rs.getInt(4);
                int carID = rs.getInt(5);
//              int  totalPrice=rs.getInt(6);
              
//      int resid, Date start, Date end, int userID, int carID, double totalPrice)  
                  
                  
               
               
               Res res1 = new Res(resID, start, end, userId, carID);
                res.add(res1);

            } catch (SQLException e) {
                System.out.println(e.getMessage());
            }

        }

        return res;

    }

    @Override
    public String toString() {
        return "Res{" + "resid=" + resid + ", start=" + start + ", end=" + end + ", userID=" + userID + ", carID=" + carID + ", totalPrice=" + totalPrice + '}';
    }


}
