package carpac;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;


public class Admin {
String email;
String password;
 int id;

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public Admin(String email, String password, int id) {
        this.email = email;
        this.password = password;
        this.id = id;
    }
//    email	password	id
    public static void insert_admin( Connection con ,String email, String password, int id ) throws SQLException{
    
       try {
        PreparedStatement pstat=con.prepareStatement("insert into admin values (?,?,?)");
           
        pstat.setString(1, email);
            pstat.setString(2, password);
            pstat.setInt(3, id);
     
            pstat.execute();   
           
       } catch (Exception e) {
           System.out.println( e.getMessage());
       }
}
}
