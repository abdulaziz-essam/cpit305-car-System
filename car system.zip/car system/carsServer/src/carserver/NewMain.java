
package carserver;

import java.sql.SQLException;
import carpac.*;
import java.sql.*;
import java.util.ArrayList;

public class NewMain {

   
    public static void main(String[] args) throws SQLException {
//  DB db=new DB();
//  
// Connection con= db.getCon();
// Statement stat = con.createStatement();
// 
// String s="aaaaaaaa/";
// s+="5";
//        System.out.println(s);
//ArrayList<Car>car=Car.storeCars(con);
//for(Car a:car){
//    System.out.println(a.toString());
//}
//        try {
////int resid, java.util.Date start, java.util.Date end, int userID, int carID, double totalPrice
//            stat.execute("ALTER TABLE reservation ADD CONSTRAINT fk_foreign_key_name2  FOREIGN KEY (car_id) REFERENCES car(carid) "); //4- use statement to execute any sql commands
////                    ("create table if not exists aek (ID int primary key, password char(10) ,email char(30),carid int )");
//        } catch (Exception e) {
//            System.out.println(e.getMessage());
//        }
// 
// 
//
//ArrayList<User>users=User.storeUSers(con);
//for(User u:users){
//    System.out.println(u.getName());
//    System.out.println("---------------------------------------------");
}
    

    }
    

