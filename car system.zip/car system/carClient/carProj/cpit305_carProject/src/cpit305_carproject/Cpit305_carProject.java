package cpit305_carproject;

import java.io.IOException;
import java.io.*;
import java.net.*;
import java.util.Scanner;
import javax.swing.JButton;
import carpac.*;
public class Cpit305_carProject {

    public static void main(String[] args) throws IOException {
     Socket socket=new Socket("localhost", 2000);
     
        InputStream is = socket.getInputStream();
        OutputStream os = socket.getOutputStream();
        Scanner input = new Scanner(is);
        PrintWriter pw = new PrintWriter(os, true);
        User user = null;
//                Socket soc,InputStream is, OutputStream os, Scanner input, PrintWriter pw,User user
        sign_in login = new sign_in(socket,is, os,input,pw,user);
        login.setVisible(true);
        
  
     
       
        
//   String email = login.getEmail();
//    String password=login.getPassword();
//        System.out.println("ggggggggggggggg");
//         
//        System.out.println(email+password);
       
//         System.out.println(login.isResult());
///*    check if email and password is correct or not(from data base but we don't finish it yet') */
//boolean result = check(email,password);
// System.out.println(login.isResult());
//login.setResult(result);
       

    } 
  
   

}
