
package cpit305_carproject;

import java.io.*;
import java.io.OutputStream;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;


public class sendData {
     Socket socket=new Socket("localhost", 2000);
     
        InputStream is = socket.getInputStream();
        OutputStream os = socket.getOutputStream();
        Scanner input = new Scanner(is);
        PrintWriter pw = new PrintWriter(os, true);
     public sendData() throws IOException {
      
    }
         
    /* set socket to set socket in send data clss to send it to  server */
    

   
    
    public Socket getSocket() {
        return socket;
    }

    public void setSocket(Socket socket) {
        this.socket = socket;
    }
   public void send_sign_in_data(String email , String password ){
    
       System.out.println(email+password+"send data method");
        pw.println(email);
      pw.println(password);
     
 
     
   }
//    public  boolean check(String email,String password){
//         System.out.println(email);
//         System.out.println(password);
////         send_sign_in_data(email, password);
//             System.out.println(email+password+"send data method");
//        pw.println(email);
//      pw.println(password);
//     
//        String res=input.nextLine();
//         System.out.println(res+"rhggewewjggewjgpwepo");
//         if(res.equalsIgnoreCase("true")){
//           
//             return true;
//         }
//         else{
//      
//           return false;
//         }
//         }
//    public Socket getSoc() {
//        return socket;
//    }

    public void setSoc(Socket soc) {
        this.socket = soc;
    }

//    public String getPass() {
//        return p;
//    }
//
//    public void setPass(String pass) {
//        this.pass = pass;
//    }

//    public boolean isResult() {
//        return result;
//    }
//
//    public void setResult(boolean result) {
//        this.result = result;
//    }

    public InputStream getIs() {
        return is;
    }

    public void setIs(InputStream is) {
        this.is = is;
    }

    public OutputStream getOs() {
        return os;
    }

    public void setOs(OutputStream os) {
        this.os = os;
    }

    public Scanner getInput() {
        return input;
    }

    public void setInput(Scanner input) {
        this.input = input;
    }

    public PrintWriter getPw() {
        return pw;
    }

    public void setPw(PrintWriter pw) {
        this.pw = pw;
    }
//    int start, int end, int userID, int carID, double Price
    public void send_Res_data(String start, String end, String userID, String carID, String Price){
        
//     Res res=new Res(start, end, userID, carID, Price);
     pw.println(start);
      pw.println(end);
       pw.println(userID);
       pw.println(carID);
        pw.println(Price);
      
    }

//    public String getLine() {
//        return line;
//    }
//
//    public void setLine(String line) {
//        this.line = line;
//    }
}
